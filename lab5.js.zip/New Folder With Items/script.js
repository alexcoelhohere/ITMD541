// script.js

document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('detailsForm')) {
        // Code for form.html
        handleFormSubmission();
    } else if (document.getElementById('resumePage')) {
        // Code for resume.html
        displayResumeData();
    }
});

function handleFormSubmission() {
    const form = document.getElementById('detailsForm');
    form.addEventListener('submit', (event) => {
        event.preventDefault(); // Prevent default form submission
        
        // Collect form data
        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone_number').value,
            degree: document.getElementById('degree').value,
            institution: document.getElementById('institute').value,
            passingYear: document.getElementById('passing Year').value,
            jobTitle: document.getElementById('job_title').value,
            company: document.getElementById('company').value,
            duration: document.getElementById('duration').value,
            responsibilities: document.getElementById('responsibility').value,
            languages: Array.from(document.querySelectorAll('.checkbox-group input[type="checkbox"]:checked')).map(el => el.value),
            frameworks: Array.from(document.querySelectorAll('.check-grp input[type="checkbox"]:checked')).map(el => el.value),
            versionControl: document.getElementById('version').value,
            projectName: document.getElementById('ProjectName').value,
            projectDescription: document.getElementById('ProjectDescription').value
        };

        // Store form data in sessionStorage
        sessionStorage.setItem('formData', JSON.stringify(formData));

        // Redirect to resume.html
        window.location.href = 'resume.html';
    });
}

function displayResumeData() {
    const formData = JSON.parse(sessionStorage.getItem('formData'));
    if (!formData) {
        // If no data, redirect to form.html
        window.location.href = 'form.html';
        return;
    }

    // Populate the fields in resume.html with data from formData
    document.getElementById('displayName').textContent = formData.name;
    document.getElementById('displayEmail').textContent = `Email: ${formData.email}`;
    document.getElementById('displayPhone').textContent = `Phone: ${formData.phone}`;
    document.getElementById('displayEducation').innerHTML = `
        <strong>Degree:</strong> ${formData.degree}<br>
        <strong>Institution:</strong> ${formData.institution}<br>
        <strong>Year:</strong> ${formData.passingYear}
    `;
    document.getElementById('displayExperience').innerHTML = `
        <strong>Job Title:</strong> ${formData.jobTitle}<br>
        <strong>Company:</strong> ${formData.company}<br>
        <strong>Duration:</strong> ${formData.duration}<br>
        <strong>Responsibilities:</strong> ${formData.responsibilities}
    `;
    document.getElementById('displaySkills').innerHTML = `
        <ul>
            <li>Languages: ${formData.languages.join(', ')}</li>
            <li>Frameworks: ${formData.frameworks.join(', ')}</li>
            <li>Version Control: ${formData.versionControl}</li>
        </ul>
    `;
    document.getElementById('displayProject').innerHTML = `
        <ul>
            <li><strong>Name:</strong> ${formData.projectName}</li>
            <li><strong>Description:</strong> ${formData.projectDescription}</li>
        </ul>
    `;
}