const apiUrl = "https://api.sunrise-sunset.org/json";

// Time zone map for locations
const timeZoneMap = {
    "-33.8688,151.2093": "Australia/Sydney", // Sydney
    "35.6895,139.6917": "Asia/Tokyo",       // Tokyo
    "28.7041,77.1025": "Asia/Kolkata",      // Delhi
    "48.8566,2.3522": "Europe/Paris",       // Paris
    "51.5074,-0.1278": "Europe/London",     // London
    "40.7128,-74.0060": "America/New_York", // New York
    "34.0522,-118.2437": "America/Los_Angeles", // Los Angeles
    "-23.5505,-46.6333": "America/Sao_Paulo" // São Paulo
};

// Update greeting, background, and time dynamically
function updateGreetingAndBackground(hour, locationTime, locationName) {
    const greetingElement = document.getElementById("greeting");
    const timeElement = document.getElementById("location-time");
    const body = document.body;

    // Determine the time of day for the greeting and background
    if (hour >= 5 && hour < 12) {
        greetingElement.innerHTML = `Good Morning, ${locationName}! ☀️`;
        body.style.backgroundImage = "url('/Users/alexcoelho/Documents/Illinois Tech/Web App Foundation LABS/ITMD541_Alex-Coelho/Lab 6/morning.jpg')";
    } else if (hour >= 12 && hour < 18) {
        greetingElement.innerHTML = `Good Afternoon, ${locationName}! 🌤️`;
        body.style.backgroundImage = "url('/Users/alexcoelho/Documents/Illinois Tech/Web App Foundation LABS/ITMD541_Alex-Coelho/Lab 6/afternoon.jpg')";
    } else if (hour >= 18 && hour < 21) {
        greetingElement.innerHTML = `Good Evening, ${locationName}! 🌆`;
        body.style.backgroundImage = "url('/Users/alexcoelho/Documents/Illinois Tech/Web App Foundation LABS/ITMD541_Alex-Coelho/Lab 6/evening.jpg')";
    } else {
        greetingElement.innerHTML = `Good Night, ${locationName}! 🌙`;
        body.style.backgroundImage = "url('/Users/alexcoelho/Documents/Illinois Tech/Web App Foundation LABS/ITMD541_Alex-Coelho/Lab 6/night.jpg')";
    }

    // Display the location time
    timeElement.textContent = `${locationName} Time: ${locationTime}`;
}

// Fetch today's and tomorrow's data
function fetchSunriseSunset(lat, lng, locationName) {
    const timeZone = timeZoneMap[`${lat},${lng}`]; // Get the time zone for the location

    fetch(`${apiUrl}?lat=${lat}&lng=${lng}&formatted=0`)
        .then(response => response.json())
        .then(data => {
            if (data.status === "OK") {
                // Get the local time of the location in 24-hour format
                const locationTime = new Date().toLocaleTimeString('en-GB', {
                    hour: '2-digit',
                    minute: '2-digit',
                    timeZone,
                    hour12: false
                });

                const locationHour = parseInt(locationTime.split(":")[0], 10); // Extract the hour
                updateGreetingAndBackground(locationHour, locationTime, locationName); // Update greeting and background
                updateTodayDashboard(data.results, timeZone); // Update today's data

                // Fetch tomorrow's data
                const tomorrow = new Date();
                tomorrow.setDate(tomorrow.getDate() + 1);
                const tomorrowDate = tomorrow.toISOString().split('T')[0];
                return fetch(`${apiUrl}?lat=${lat}&lng=${lng}&formatted=0&date=${tomorrowDate}`);
            } else {
                throw new Error("Failed to retrieve today's data.");
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === "OK") {
                updateTomorrowDashboard(data.results, timeZone);
            } else {
                throw new Error("Failed to retrieve tomorrow's data.");
            }
        })
        .catch(error => {
            alert("An error occurred: " + error.message);
        });
}

// Update today's data
function updateTodayDashboard(data, timeZone) {
    document.getElementById("todaySunrise").textContent = convertToTimeZone(data.sunrise, timeZone);
    document.getElementById("todaySunset").textContent = convertToTimeZone(data.sunset, timeZone);
    document.getElementById("todayDawn").textContent = convertToTimeZone(data.civil_twilight_begin, timeZone);
    document.getElementById("todayDusk").textContent = convertToTimeZone(data.civil_twilight_end, timeZone);
    document.getElementById("todayLength").textContent = formatDayLength(data.day_length);
    document.getElementById("todayNoon").textContent = convertToTimeZone(data.solar_noon, timeZone);
}

// Update tomorrow's data
function updateTomorrowDashboard(data, timeZone) {
    document.getElementById("tomorrowSunrise").textContent = convertToTimeZone(data.sunrise, timeZone);
    document.getElementById("tomorrowSunset").textContent = convertToTimeZone(data.sunset, timeZone);
    document.getElementById("tomorrowDawn").textContent = convertToTimeZone(data.civil_twilight_begin, timeZone);
    document.getElementById("tomorrowDusk").textContent = convertToTimeZone(data.civil_twilight_end, timeZone);
    document.getElementById("tomorrowLength").textContent = formatDayLength(data.day_length);
    document.getElementById("tomorrowNoon").textContent = convertToTimeZone(data.solar_noon, timeZone);
}

// Convert UTC to the specified time zone
function convertToTimeZone(utcTime, timeZone) {
    return new Date(utcTime).toLocaleTimeString('en-GB', {
        hour: '2-digit',
        minute: '2-digit',
        timeZone,
        hour12: false
    });
}

// Format day length in hours and minutes
function formatDayLength(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours} hours and ${minutes} minutes`;
}

// Detect current location
document.getElementById("currentLocation").addEventListener("click", () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            fetchSunriseSunset(position.coords.latitude, position.coords.longitude, "Your Current Location");
        }, () => {
            alert("Could not get your location. Please allow location access.");
        });
    } else {
        alert("Geolocation is not supported by this browser.");
    }
});

// Set initial greeting and time based on local time
const localHour = new Date().getHours();
const localTime = new Date().toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
});
updateGreetingAndBackground(localHour, localTime, "Your Location");

// Event listener for location dropdown
document.getElementById("fetchData").addEventListener("click", () => {
    const locationSelect = document.getElementById("locations");
    const location = locationSelect.value.split(",");
    const locationName = locationSelect.options[locationSelect.selectedIndex].text;
    fetchSunriseSunset(location[0], location[1], locationName);
});