(function() {
    // Update the hero headline and subheading
    document.querySelector("#hero h1").textContent = "Supercharge Your Brand with Stellar Marketing";
    document.querySelector("#hero p").innerHTML = "Leverage innovative strategies from Stellar Marketing to make your business <strong><em>shine</strong></em> and <strong><em>succeed</strong></em>.";

    // Change the hero background image
    document.querySelector("#hero").style.backgroundImage = "url('https://picsum.photos/id/683/1280/720')";

    // Update nav bar color to match footer
    document.querySelector("header").style.backgroundColor = "#2d3748";  // Assuming the footer uses #2d3748

    // Remove the 'Get Started' CTA from the hero section
    let ctaButton = document.querySelector("#hero a");
    if (ctaButton) {
        ctaButton.remove();
    }

    // Add new CTA section below hero
    let newCTASection = document.createElement("section");
    newCTASection.style.cssText = `
        background-color: #6495ed;
        padding: 32px 0;
        width: 100%;
        text-align: center;
    `;

    // Create the CTA button with specified styles
    let newCTAButton = document.createElement("button");
    newCTAButton.textContent = "Schedule a Consultation Today";
    newCTAButton.style.cssText = `
        background-color: white;
        color: #6495ed;
        padding: 12px 24px;
        font-size: 1rem;
        font-weight: normal;  /* Regular text weight */
        border: 4px solid #6495ed;
        border-radius: 5px;
        cursor: pointer;
        box-shadow: 0 2px 4px #000080;  /* Navy blue drop shadow */
    `;

    // Add click event to show alert
    newCTAButton.onclick = function() {
        alert("Thank You for your interest in Stellar Marketing!");
    };

    // Append the button to the new section
    newCTASection.appendChild(newCTAButton);
    document.querySelector("main").insertBefore(newCTASection, document.querySelector("#services"));

    // Override the margin-bottom on the hero section using JS
    document.querySelector("#hero").style.marginBottom = "0";

    // Add a margin-top of 1.5rem to the "Our Services" h2
    let servicesHeading = document.querySelector("#services h2");
    if (servicesHeading) {
        servicesHeading.style.marginTop = "2.5rem";
    }

    // Change icon colors in services section
    document.querySelectorAll("#services .material-symbols-outlined").forEach(icon => {
        icon.style.color = "#6495ed";
    });

    // Change the Digital Marketing icon to 'Ads Click'
    let digitalMarketingIcon = document.querySelector("[data-icon='digital']");
    if (digitalMarketingIcon) {
        digitalMarketingIcon.textContent = "ads_click";
    }

    // Update layout in specialized marketing solutions section for larger screens
    let productCards = document.querySelector("[data-section='product_cards']");
    if (productCards) {
        productCards.classList.remove("md:grid-cols-2");
        productCards.classList.add("md:grid-cols-4");
    }

    // Change the Musicians image
    let musiciansImage = document.querySelector("[alt='Musicians']");
    if (musiciansImage) {
        musiciansImage.src = "https://picsum.photos/id/453/400/300";
    }

    // Form submission behavior for Graduate requirement
    document.querySelector("form").addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent the form from submitting

        let name = document.getElementById("name").value.trim();
        let email = document.getElementById("email").value.trim();

        if (name && email) {
            alert(`Thank you, ${name}! We will be in touch with you shortly at ${email}.`);
        } else {
            alert("Please provide a name and email.");
        }
    });
})();
