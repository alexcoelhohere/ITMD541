function countVowels(str) {
    const vowels = 'aeiouAEIOU';
    let count = 0;
    
    for (let char of str) {
        if (vowels.includes(char)) {
            count++;
        }
    }

    return count;
}

// Test cases
console.log(`word: "Alex", vowels: ${countVowels("Alex")}`);
console.log(`word: "Merlin", vowels: ${countVowels("Merlin")}`);
console.log(`word: "Chelsea", vowels: ${countVowels("Chelsea")}`);