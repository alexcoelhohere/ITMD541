function sortNumbers(arr) {
    return arr.sort((a, b) => a - b);
}

// Test cases
console.log(`Original Array: [55, 33, 88, 11, 44], Sorted Array: ${sortNumbers([55, 33, 88, 11, 44])}`);
console.log(`Original Array: [112, 897, 2149, 21], Sorted Array: ${sortNumbers([112, 897, 2149, 21])}`);
console.log(`Original Array: [2341, 1675, 9874, 8231], Sorted Array: ${sortNumbers([2341, 1675, 9874, 8231])}`);