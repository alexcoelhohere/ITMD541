function sortPeopleByAge(people) {
    const sortedPeople = people.sort((a, b) => a.age - b.age);
    return sortedPeople.map(person => `${person.name} is ${person.age} and from ${person.city}`);
}

// Test cases
const people1 = [
    {name: 'Alex', age: 24, city: 'Chicago'},
    {name: 'Merlin', age: 28, city: 'New York'},
    {name: 'Saby', age: 26, city: 'Dubai'},
    {name: 'Symona', age: 25, city: 'Dubai'},
    {name: 'Chelsea', age: 22, city: 'London'}
];

const people2 = [
    {name: 'Cole', age: 22, city: 'London'},
    {name: 'Kevin', age: 32, city: 'Manchester'},
    {name: 'Mbappe', age: 25, city: 'Madrid'},
    {name: 'Sbozslai', age: 24, city: 'Liverpool'},
    {name: 'Yamal', age: 18, city: 'Barcelona'}
];

console.log(sortPeopleByAge(people1));
console.log(sortPeopleByAge(people2));