function celsiusToFahrenheit(celsius) {
    if (typeof celsius === 'string') {
        celsius = parseFloat(celsius);
    }
    const fahrenheit = (celsius * 9/5) + 32;
    console.log(`${celsius.toFixed(1)} Celsius = ${fahrenheit.toFixed(1)} Fahrenheit`);
}

// Test cases
celsiusToFahrenheit(25);
celsiusToFahrenheit(0);
celsiusToFahrenheit(-10);
celsiusToFahrenheit('3');
celsiusToFahrenheit('1');